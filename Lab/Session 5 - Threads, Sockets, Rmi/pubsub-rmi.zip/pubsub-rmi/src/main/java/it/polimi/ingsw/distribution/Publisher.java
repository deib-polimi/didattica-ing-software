package it.polimi.ingsw.distribution;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Random;
import java.util.Scanner;

import it.polimi.ingsw.distribution.common.BrokerInterface;
import it.polimi.ingsw.distribution.common.PublisherInterface;

public class Publisher<M,T> implements PublisherInterface<M, T>{

	BrokerInterface<M, T> broker;
	T topic;
	
	public Publisher(BrokerInterface<M, T> b, T t) {
		broker = b;
		topic = t;
	}
	
	@Override
	public BrokerInterface<M, T> getBroker() {
		return broker;
	}
	
	public static void main(String[] argv){
		try {
		
		System.out.println("Type the topic you want to publish about:");
		Scanner sc = new Scanner(System.in);
		String topic = sc.nextLine();
		
		Registry reg = LocateRegistry.getRegistry(8001);
		
		BrokerInterface<String,String> broker = (BrokerInterface<String,String>) reg.lookup("BROKER");
		
		
		Thread publisherThread = new Thread(){
			private Publisher<String, String> publisher = new Publisher<String, String>(broker, topic);
			
			@Override
			public void run(){
				Random r = new Random(1);
				int num = r.nextInt(10000);
				try {
					while(true){
						publisher.publish("Message "+ num, topic);
						Thread.sleep(5000L+num);
						num = r.nextInt(10000);
					}
				} catch (InterruptedException e) {
					
				}
			}
			
		};
		
		publisherThread.start();
		
		
		
		
		System.out.println("Publisher started");
		System.out.println("(Type 'exit' to stop...)");
		
		String command = "";
		while(!command.equals("exit")){
			command = sc.nextLine();
		}
		
		publisherThread.interrupt();
		sc.close();
		
		
		} catch (RemoteException | NotBoundException e) {
			
		} 
	}
		
	

}
