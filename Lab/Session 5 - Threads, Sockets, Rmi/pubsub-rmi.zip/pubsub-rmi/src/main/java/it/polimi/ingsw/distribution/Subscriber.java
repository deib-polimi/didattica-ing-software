package it.polimi.ingsw.distribution;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

import it.polimi.ingsw.distribution.common.BrokerInterface;
import it.polimi.ingsw.distribution.common.SubscriberInterface;


public class Subscriber<M> implements SubscriberInterface<M> {

	
	
	public void dispatchMessage(M msg) throws RemoteException {
		System.out.println(msg);
	}
	public static void main(String[] args) {
		try {
			
			//LocateRegistry class provides static methods for synthesizing 
        	//a remote reference to a registry at a particular network 
        	//address (host and port). In this case 'localhost' is assumed.
        	//The no-argument overload of getRegisry uses port 1099
			Registry reg = LocateRegistry.getRegistry(8001);
			
			//lookup method searches for the remote interface binded to name "Broker" 
    		//in the server host's registry
			BrokerInterface<String,String> broker = (BrokerInterface<String,String>) reg.lookup("BROKER");
			
			//subscriber exports its own remote interface SubscriberInterface so that it can 
			//receive invocations from remote brokers.
			Subscriber<String> subscriber = new Subscriber<String>();
			SubscriberInterface<String> subInt = (SubscriberInterface<String>) UnicastRemoteObject.exportObject(subscriber,0);
			System.out.println("Subscriber started");
			
			System.out.println("Type the topic you want to subscribe:");
			Scanner sc = new Scanner(System.in);
			String topic = sc.nextLine();
			
			//Then it invokes subscribe remote method of the BrokerInterface and passes it's 
			//own remote interface as a parameter.
			broker.subscribe(subInt, topic);
			System.out.println("Subscribed to " + topic + " receiving messages...");
			System.out.println("(Type 'exit' to stop...)");
			String command = "";
			while(!command.equals("exit")){
				command = sc.nextLine();
			}
			
			//Once done it invokes unsubscribe remote method of the BrokerInterface 
			broker.unsubscribe(subInt, topic);
			
			//then it unexports the remote SubscribeInterface
			UnicastRemoteObject.unexportObject(subscriber, true);
			sc.close();
			
		} catch (RemoteException | NotBoundException  e) {
			
		}
		

	}

}
