package it.polimi.ingsw.distribution.common;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface BrokerInterface<M,T> extends Remote {
	public void subscribe(SubscriberInterface<M> s, T topic) throws RemoteException;
	public void unsubscribe(SubscriberInterface<M> s, T topic) throws RemoteException;
	public void publish(M msg, T topic) throws RemoteException;
}
