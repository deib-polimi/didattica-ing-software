package it.polimi.ingsw.distribution.common;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SubscriberInterface<M> extends Remote{
	public void dispatchMessage(M msg) throws RemoteException;
}
