package it.polimi.ingsw.distribution;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import it.polimi.ingsw.distribution.common.BrokerInterface;
import it.polimi.ingsw.distribution.common.SubscriberInterface;

public class Broker<M,T> implements BrokerInterface<M, T> {
	private Map<T,Set<SubscriberInterface<M>>> subscriptions  = new HashMap<T, Set<SubscriberInterface<M>>>();

	public void subscribe(SubscriberInterface<M> s, T topic) throws RemoteException {
		synchronized (subscriptions) {
			if(!subscriptions.containsKey(topic)){
				subscriptions.put(topic, new HashSet<SubscriberInterface<M>>());
			}
			subscriptions.get(topic).add(s);
			System.out.println("Adding new subscriber");
		}
	}
	public void unsubscribe(SubscriberInterface<M> s, T topic) throws RemoteException{
		synchronized (subscriptions) {
			if(subscriptions.containsKey(topic)){
				subscriptions.get(topic).remove(s);
				System.out.println("Removing a subscriber");			
			}
		}
	}

	public void publish(M message, T topic) throws RemoteException {
		synchronized (subscriptions) {
			Set<SubscriberInterface<M>> subs = subscriptions.get(topic);
			if(subs!=null){
				for (SubscriberInterface<M> sub: subs) {
					sub.dispatchMessage(message);
				}			
			}
		}
		
	}
	
	public static void main(String[] argv){
		try {
			
			//RMI provides a particular type of remote object, the RMI registry, 
			//for finding references to other remote objects. The RMI registry 
			//is a simple naming service that enables clients 
			//to obtain a reference to a remote object by name. 
			//The registry is typically only used to locate the first remote 
			//object that an RMI client needs to use. That first remote object 
			//might then provide support for finding other objects.
			//First, we create an RMI registry on port 8001
			Registry reg = LocateRegistry.createRegistry(8001);
			Broker<String,String> broker = new Broker<String,String>();
			
			//Export the supplied remote object so that it can receive 
			//invocations of its remote methods from remote clients. 
			//The second argument specifies which TCP port to use 
			//to listen for incoming remote invocation requests for the object. 
			//It is common to use the value zero, which specifies the use of 
			//an anonymous port. The actual port will then be chosen at runtime by RMI
			BrokerInterface<String,String> brokerInt = (BrokerInterface<String,String>) UnicastRemoteObject.exportObject(broker, 0);
			
			//This rebind(name,interface) invocation makes a remote call to the RMI registry 
			//on the local host and binds the name "broker" to the remote interface "BrokerInterface".
			reg.rebind("BROKER", brokerInt);
			System.out.println("Broker started");
			System.out.println("(Type 'exit' to stop...)");
			
			Scanner sc = new Scanner(System.in);
			String command = "";
			while(!command.equals("exit")){
				command = sc.nextLine();
			}
			
			//when you are exposing objects through RMI it needs a thread to accept 
			//incoming requests for these objects. 
			//This thread could be a daemon thread which wouldn't stop the JVM from exiting.
			//To stop the threads use unexportObject for all remote objects and unbind 
			//them in the registry
			reg.unbind("BROKER");
			UnicastRemoteObject.unexportObject(broker, true);
			sc.close();
			
		} catch (RemoteException e) {
			
		} catch (NotBoundException e) {
			
		} catch (NoSuchElementException e){
			
		}
	}

}
