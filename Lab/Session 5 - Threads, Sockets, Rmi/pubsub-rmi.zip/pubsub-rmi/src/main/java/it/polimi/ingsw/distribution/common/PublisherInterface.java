package it.polimi.ingsw.distribution.common;

import java.rmi.RemoteException;

public interface PublisherInterface<M,T> {
	
	public BrokerInterface<M,T> getBroker();
	default public void publish(M msg, T topic){
		try {
			getBroker().publish(msg, topic);
		} catch (RemoteException e) {
			
		}
	}
}
