package it.polimi.ingsw.distribution;

import java.io.IOException;
import java.io.Serializable;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;

import it.polimi.ingsw.distribution.common.SubscriberInterface;
import it.polimi.ingsw.distribution.common.sockets.SocketCommunicator;

public class Subscriber<M extends Serializable> extends Thread implements SubscriberInterface<M> {

	private boolean done = false;
	private SocketCommunicator<M> comm;

	@Override
	public void run() {
		try {
			while(!done){
				M message = comm.receive();
				System.out.println(message);
			
			}
		} catch (SocketException e) {
			
		}
		comm.close();
	}

	public Subscriber(SocketCommunicator<M> sc) {
		comm = sc;
	}
	public void dispatchMessage(M msg) {
		comm.send(msg);
	}
	
	public static void main(String [] argv){
		
		try {
			System.out.println("Subscriber started");
			System.out.println("Type the topic you want to subscribe:");

			Scanner sc = new Scanner(System.in);
			String topic = sc.nextLine();
			
			Socket socket = new Socket("127.0.0.1", 8000);
			Subscriber<String> server = new Subscriber<String>(new SocketCommunicator<String>(socket));
			server.start();

			server.dispatchMessage(topic);
			
			System.out.println("Subscribed to " + topic + " receiving messages...");
			System.out.println("(Type 'exit' to stop...)");
			String command = "";
			while(!command.equals("exit")){
				command = sc.nextLine();
			}
			
			server.dispatchMessage(topic);
			server.done = true;
			socket.close();
			sc.close();

		} catch (IOException e) {
			
		} 
		
	}

}
