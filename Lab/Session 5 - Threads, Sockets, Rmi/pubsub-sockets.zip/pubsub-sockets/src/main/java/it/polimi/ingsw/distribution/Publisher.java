package it.polimi.ingsw.distribution;

import java.io.Serializable;

import it.polimi.ingsw.distribution.common.BrokerInterface;
import it.polimi.ingsw.distribution.common.PublisherInterface;

public class Publisher<M extends Serializable, T extends Serializable> extends Thread implements PublisherInterface<M,T> {

	
	private Broker<M,T> broker;
	
	public Publisher(Broker<M,T> b, T t) {
		broker = b;
	}

	public BrokerInterface<M,T> getBroker() {
		return broker;
	}

}
