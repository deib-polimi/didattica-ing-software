package it.polimi.ingsw.distribution.common;


public interface PublisherInterface<M,T> {
	
	public BrokerInterface<M,T> getBroker();
	default public void publish(M msg, T topic) {
		getBroker().publish(msg, topic);
	}
}
