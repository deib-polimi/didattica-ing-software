package it.polimi.ingsw.distribution.common;


public interface SubscriberInterface<M> {
	public void dispatchMessage(M msg);
}
