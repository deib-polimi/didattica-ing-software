package it.polimi.ingsw.distribution;

import java.io.Serializable;
import java.net.SocketException;
import java.util.concurrent.ConcurrentLinkedQueue;

import it.polimi.ingsw.distribution.common.BrokerInterface;
import it.polimi.ingsw.distribution.common.SubscriberInterface;
import it.polimi.ingsw.distribution.common.sockets.SocketCommunicator;

public class SubscriberHandler<M extends Serializable,T extends Serializable> extends Thread implements SubscriberInterface<M>{

	private ConcurrentLinkedQueue<M> buffer = new ConcurrentLinkedQueue<M>();;

	BrokerInterface<M, T> broker;
	
	SocketCommunicator<Serializable> comm;
	public SubscriberHandler(BrokerInterface<M,T> b, SocketCommunicator<Serializable> sc) {
		comm = sc;
		broker = b;
	}
	public void dispatchMessage(M msg) {
		buffer.add(msg);
		synchronized(buffer){
			buffer.notify();
		}
	}
	
	@Override
	public void run() {
		try {
			T topic = (T) comm.receive();
			broker.subscribe(this, topic);
		} catch (SocketException e1) {
			
		}
		Thread unsubscribe = new Thread(){
			@Override
			public void run() {
				try {
					T topic = (T) comm.receive();
					broker.unsubscribe(SubscriberHandler.this, topic);
					System.out.println("Removing a subscriber");
				} catch (SocketException e) {
					
				}
				
			}
		};
		unsubscribe.start();
		
		while(!isDone()){
			M msg = buffer.poll();
			if(msg != null) comm.send(msg);
			else{
				
				try {
					synchronized(buffer){
						buffer.wait();
					}
				} catch (InterruptedException e) {
				}
			}
		}
	}
	
	private boolean done;
	private boolean isDone() {
		return done;
	}
	public void finish(){
		done=true;
	}
	

}
