package it.polimi.ingsw.distribution;

import java.io.IOException;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import it.polimi.ingsw.distribution.common.BrokerInterface;
import it.polimi.ingsw.distribution.common.SubscriberInterface;
import it.polimi.ingsw.distribution.common.sockets.SocketCommunicator;


public class Broker<M extends Serializable,T extends Serializable> implements BrokerInterface<M,T> {
	private Map<T,Set<SubscriberInterface<M>>> subscriptions  = new HashMap<T, Set<SubscriberInterface<M>>>();
	
	private boolean doneSub = false;
	private ServerSocket brokerSubscriberSocket=null;
	private Thread subscriberListener;
	private Set<Thread> publishers = new HashSet<Thread>();


	public static void main(String[] args) {
		
		Broker<String,String> broker = new Broker<String,String>();
		broker.startSubscriberListener();
		broker.startPublishers(broker,3);
		
		System.out.println("Broker started");
		System.out.println("(Type 'exit' to stop...)");
		
		Scanner sc = new Scanner(System.in);
		String command = "";
		while(!command.equals("exit")){
			command = sc.nextLine();
		}
		

		broker.stopSubscriberListener();
		broker.stopPublishers();

		try {
			broker.brokerSubscriberSocket.close();
		} catch (IOException e) {
		}
		sc.close();
		
	}


	private void stopPublishers() {
		for (Thread thread : publishers) {
			thread.interrupt();
		}
		
	}

	private void startPublishers(Broker<String,String> b, int N) {
		for(int i = 1; i<=N;i++){
			final int a = i;
			Thread p = new Thread(){
				Publisher<String, String> publisher = new Publisher<String, String>(b, "game"+a);
				@Override
				public void run() {
					Random r = new Random(1);
					int num = r.nextInt(10000);
					try {
					while(true){
							publisher.publish("Message "+ num, "game"+a);
							Thread.sleep(5000L+num);
							num = r.nextInt(10000);
						}
					} catch (InterruptedException e) {
						
					}
				}
			};
			p.start();
			publishers.add(p);
		}
		
	}


	private void startSubscriberListener() {
		subscriberListener = new Thread(){
			@Override
			public void run() {
				try{
					brokerSubscriberSocket = new ServerSocket(8000);
					brokerSubscriberSocket.setSoTimeout(3000);
					while(!doneSub){
						try{
							Socket client = brokerSubscriberSocket.accept();
							SubscriberHandler<M,T> handler = new SubscriberHandler<M,T>(Broker.this, new SocketCommunicator<Serializable>(client));
							handler.start();
							System.out.println("Adding new subscriber");			
						}
						catch(SocketTimeoutException | SocketException e){
							
						}
					}
					brokerSubscriberSocket.close();
				}
				catch(IOException e){
					throw new AssertionError("Error closing the socket",e);
				}
				finally{
					if(brokerSubscriberSocket!=null){
						try {
							brokerSubscriberSocket.close();
						} catch (IOException e) {
							throw new AssertionError("Error closing the socket",e);
						}
					}
				}
			}
		};
		subscriberListener.start();
		
	}

	private void stopSubscriberListener() {
		doneSub = true;
		subscriberListener.interrupt();
	}



	public void subscribe(SubscriberInterface<M> s, T topic) {
		synchronized (subscriptions) {
			if(!subscriptions.containsKey(topic)){
				subscriptions.put(topic, new HashSet<SubscriberInterface<M>>());
			}
			subscriptions.get(topic).add(s);			
		}	
	}

	public void unsubscribe(SubscriberInterface<M> s, T topic) {
		synchronized (subscriptions) {
			if(subscriptions.containsKey(topic)){
				subscriptions.get(topic).remove(s);
				SubscriberHandler<M,T> handler = (SubscriberHandler<M,T>)s;
				handler.finish();
				handler.interrupt();
			}
		}
	}

	public void publish(M msg, T topic) {
		Set<SubscriberInterface<M>> subs = subscriptions.get(topic);
		if(subs!=null){
			for (SubscriberInterface<M> sub: subs) {
				sub.dispatchMessage(msg);
			}
		}
		
	}



}
