package it.polimi.ingsw.distribution.common;


public interface BrokerInterface<M,T>{
	public void subscribe(SubscriberInterface<M> s, T topic);
	public void unsubscribe(SubscriberInterface<M> s, T topic);
	public void publish(M msg, T topic);
}
