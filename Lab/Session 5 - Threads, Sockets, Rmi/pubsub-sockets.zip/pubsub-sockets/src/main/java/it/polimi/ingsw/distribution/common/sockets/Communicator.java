package it.polimi.ingsw.distribution.common.sockets;

import java.io.Serializable;
import java.net.SocketException;

public interface Communicator<M extends Serializable> {
	
	public M receive() throws SocketException;
	public void send(M message);

}
