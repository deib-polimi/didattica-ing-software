package it.polimi.ingsw.distribution.common.sockets;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.SocketException;
import java.util.NoSuchElementException;

public class SocketCommunicator<M extends Serializable> implements Communicator<M> {

	Socket socket;
	ObjectInputStream in;
	ObjectOutputStream out;
	
	public SocketCommunicator(Socket sc) {
		socket = sc;
		
		try{
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());
		}catch (IOException ex) {
            
        }
	}
	
	public M receive() throws SocketException{
		try{
			return ((M) in.readObject());
		}catch(NoSuchElementException | ClassNotFoundException | IOException e){
			throw new SocketException("Socket failed");
		}
	}

	public void send(M message) {
		try {
			out.writeObject(message);
			out.flush();
		} catch (IOException e) {
			
		}
	}
	
	public void close(){
		try {
			socket.close();
		} catch (IOException e) {
			throw new AssertionError("error closing the socket", e);
		}
	}

}
